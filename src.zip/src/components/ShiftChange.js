import React from 'react'

function ShiftChange({ shiftDetails }) {
  console.log(shiftDetails)
  return (
    <div>
      <h1 className="text-3xl mb-5 font-semibold text-gray-600">
        Request Shift Change{' '}
      </h1>
    </div>
  )
}

export default ShiftChange
